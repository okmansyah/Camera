package com.example.gpscamera

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.*
import android.location.Location
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.CountDownTimer
import android.provider.MediaStore
import android.view.GestureDetector
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.core.Camera
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import com.example.gpscamera.databinding.ActivityMainBinding
import com.google.android.gms.location.*
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    // ---- Kamera ----
    private var imageCapture: ImageCapture? = null
    private var preview: Preview? = null
    private var camera: Camera? = null
    private var cameraProvider: ProcessCameraProvider? = null
    private var lensFacing = CameraSelector.LENS_FACING_BACK
    private var currentAspectRatio = AspectRatio.RATIO_4_3
    private var flashMode = ImageCapture.FLASH_MODE_OFF // OFF -> AUTO -> ON -> TORCH(khusus)
    private var isTorchOn = false
    private var timerSeconds = 0 // 0 = mati, opsi lain 3 / 10
    private var isCapturing = false

    // ---- Lokasi ----
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private var lastLocation: Location? = null

    // ---- Gesture ----
    private lateinit var scaleGestureDetector: ScaleGestureDetector
    private lateinit var tapGestureDetector: GestureDetector

    private val requiredPermissions = arrayOf(
        Manifest.permission.CAMERA,
        Manifest.permission.ACCESS_FINE_LOCATION
    )

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (results.values.all { it }) {
            startCamera()
            startLocationUpdates()
        } else {
            Toast.makeText(this, "Izin kamera & lokasi diperlukan", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Perangkat tanpa kamera sama sekali -> keluar dengan pesan, jangan crash
        if (!packageManager.hasSystemFeature(android.content.pm.PackageManager.FEATURE_CAMERA_ANY)) {
            Toast.makeText(this, "Perangkat ini tidak memiliki kamera", Toast.LENGTH_LONG).show()
            finish()
            return
        }

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        setupGestures()
        setupTopControls()
        setupExposureSlider()

        if (hasPermissions()) {
            startCamera()
            startLocationUpdates()
        } else {
            permissionLauncher.launch(requiredPermissions)
        }

        binding.btnCapture.setOnClickListener { onCaptureRequested() }
    }

    private fun hasPermissions() = requiredPermissions.all {
        ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
    }

    private fun hasFrontCamera() =
        packageManager.hasSystemFeature(android.content.pm.PackageManager.FEATURE_CAMERA_FRONT)

    // =====================================================================
    // KAMERA: setup, bind use case, ganti lensa, rasio
    // =====================================================================

    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            cameraProvider = cameraProviderFuture.get()
            bindCameraUseCases()
        }, ContextCompat.getMainExecutor(this))
    }

    private fun bindCameraUseCases() {
        val provider = cameraProvider ?: return

        preview = Preview.Builder()
            .setTargetAspectRatio(currentAspectRatio)
            .build()
            .also { it.setSurfaceProvider(binding.previewView.surfaceProvider) }

        imageCapture = ImageCapture.Builder()
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
            .setTargetAspectRatio(currentAspectRatio)
            .setFlashMode(
                if (flashMode == ImageCapture.FLASH_MODE_OFF ||
                    flashMode == ImageCapture.FLASH_MODE_AUTO ||
                    flashMode == ImageCapture.FLASH_MODE_ON
                ) flashMode else ImageCapture.FLASH_MODE_OFF
            )
            .build()

        val cameraSelector = CameraSelector.Builder()
            .requireLensFacing(lensFacing)
            .build()

        try {
            provider.unbindAll()
            camera = provider.bindToLifecycle(this, cameraSelector, preview, imageCapture)
            applyTorchState()
            setupExposureRangeForCurrentCamera()
            camera?.cameraInfo?.zoomState?.observe(this) { zoomState ->
                binding.tvZoomLevel.text = "%.1fx".format(zoomState.zoomRatio)
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal membuka kamera: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun switchCamera() {
        lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK) {
            if (!hasFrontCamera()) {
                Toast.makeText(this, "Kamera depan tidak tersedia di perangkat ini", Toast.LENGTH_SHORT).show()
                return
            }
            CameraSelector.LENS_FACING_FRONT
        } else {
            CameraSelector.LENS_FACING_BACK
        }
        bindCameraUseCases()
    }

    // =====================================================================
    // PANEL KONTROL ATAS: flash, ganti kamera, grid, rasio, timer
    // =====================================================================

    private fun setupTopControls() {
        binding.btnFlash.setOnClickListener { cycleFlashMode() }
        binding.btnSwitchCamera.setOnClickListener { switchCamera() }
        binding.btnGrid.setOnClickListener { toggleGrid() }
        binding.btnAspect.setOnClickListener { toggleAspectRatio() }
        binding.btnTimer.setOnClickListener { cycleTimer() }
        binding.btnInfo.setOnClickListener { showInfoDialog() }
    }

    private fun showInfoDialog() {
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Tentang Aplikasi")
            .setMessage("Aplikasi ini dibuat oleh okman_script (Koptan Makmur Jaya).")
            .setPositiveButton("OK") { dialog, _ -> dialog.dismiss() }
            .show()
    }

    private fun cycleFlashMode() {
        // Urutan: OFF -> AUTO -> ON -> TORCH -> OFF
        when {
            flashMode == ImageCapture.FLASH_MODE_OFF && !isTorchOn -> {
                flashMode = ImageCapture.FLASH_MODE_AUTO
                binding.btnFlash.text = "⚡ Auto"
            }
            flashMode == ImageCapture.FLASH_MODE_AUTO -> {
                flashMode = ImageCapture.FLASH_MODE_ON
                binding.btnFlash.text = "⚡ On"
            }
            flashMode == ImageCapture.FLASH_MODE_ON -> {
                isTorchOn = true
                binding.btnFlash.text = "🔦 Torch"
            }
            else -> {
                isTorchOn = false
                flashMode = ImageCapture.FLASH_MODE_OFF
                binding.btnFlash.text = "⚡ Off"
            }
        }
        imageCapture?.flashMode = if (isTorchOn) ImageCapture.FLASH_MODE_OFF else flashMode
        applyTorchState()
    }

    private fun applyTorchState() {
        val cam = camera ?: return
        if (cam.cameraInfo.hasFlashUnit()) {
            cam.cameraControl.enableTorch(isTorchOn)
        } else if (isTorchOn) {
            isTorchOn = false
            binding.btnFlash.text = "⚡ Off"
            Toast.makeText(this, "Perangkat ini tidak punya lampu flash", Toast.LENGTH_SHORT).show()
        }
    }

    private fun toggleGrid() {
        val showing = binding.gridOverlay.visibility == android.view.View.VISIBLE
        binding.gridOverlay.visibility = if (showing) android.view.View.GONE else android.view.View.VISIBLE
        binding.btnGrid.text = if (showing) "▦ Grid" else "▦ ON"
    }

    private fun toggleAspectRatio() {
        currentAspectRatio = if (currentAspectRatio == AspectRatio.RATIO_4_3) {
            binding.btnAspect.text = "16:9"
            AspectRatio.RATIO_16_9
        } else {
            binding.btnAspect.text = "4:3"
            AspectRatio.RATIO_4_3
        }
        bindCameraUseCases()
    }

    private fun cycleTimer() {
        timerSeconds = when (timerSeconds) {
            0 -> 3
            3 -> 10
            else -> 0
        }
        binding.btnTimer.text = if (timerSeconds == 0) "⏱ Off" else "⏱ ${timerSeconds}s"
    }

    // =====================================================================
    // ZOOM (cubit layar) & TAP-TO-FOCUS
    // =====================================================================

    private fun setupGestures() {
        scaleGestureDetector = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                val cam = camera ?: return true
                val currentZoomRatio = cam.cameraInfo.zoomState.value?.zoomRatio ?: 1f
                val newZoomRatio = currentZoomRatio * detector.scaleFactor
                cam.cameraControl.setZoomRatio(newZoomRatio)
                return true
            }
        })

        tapGestureDetector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onSingleTapUp(e: MotionEvent): Boolean {
                focusOnPoint(e.x, e.y)
                return true
            }
        })

        binding.previewView.setOnTouchListener { _, event ->
            scaleGestureDetector.onTouchEvent(event)
            tapGestureDetector.onTouchEvent(event)
            true
        }
    }

    private fun focusOnPoint(x: Float, y: Float) {
        val cam = camera ?: return
        val factory = binding.previewView.meteringPointFactory
        val point = factory.createPoint(x, y)
        val action = FocusMeteringAction.Builder(point, FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE)
            .setAutoCancelDuration(3, TimeUnit.SECONDS)
            .build()
        cam.cameraControl.startFocusAndMetering(action)
    }

    // =====================================================================
    // EXPOSURE COMPENSATION
    // =====================================================================

    private fun setupExposureSlider() {
        binding.seekExposure.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                val cam = camera ?: return
                val range = cam.cameraInfo.exposureState.exposureCompensationRange
                val index = range.lower + progress
                if (cam.cameraInfo.exposureState.isExposureCompensationSupported) {
                    cam.cameraControl.setExposureCompensationIndex(index)
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
    }

    private fun setupExposureRangeForCurrentCamera() {
        val cam = camera ?: return
        val exposureState = cam.cameraInfo.exposureState
        if (!exposureState.isExposureCompensationSupported) {
            binding.seekExposure.isEnabled = false
            return
        }
        val range = exposureState.exposureCompensationRange
        val span = range.upper - range.lower
        binding.seekExposure.isEnabled = true
        binding.seekExposure.max = span
        // Posisikan slider di titik 0 EV (netral) relatif terhadap range
        binding.seekExposure.progress = exposureState.exposureCompensationIndex - range.lower
    }

    // =====================================================================
    // LOKASI (termasuk ketinggian / altitude)
    // =====================================================================

    private fun startLocationUpdates() {
        if (ContextCompat.checkSelfPermission(
                this, Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) return

        val request = LocationRequest.Builder(
            Priority.PRIORITY_HIGH_ACCURACY, 3000L
        ).build()

        val callback = object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                val loc = result.lastLocation ?: return
                lastLocation = loc
                val altText = if (loc.hasAltitude()) "${"%.1f".format(loc.altitude)} m" else "-"
                binding.tvGpsStatus.text =
                    "Lat: ${"%.6f".format(loc.latitude)}  Lon: ${"%.6f".format(loc.longitude)}\n" +
                    "Ketinggian: $altText"
            }
        }

        fusedLocationClient.requestLocationUpdates(request, callback, mainLooper)
    }

    // =====================================================================
    // TOMBOL VOLUME UNTUK JEPRET (kompatibel berbagai perangkat)
    // =====================================================================

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            onCaptureRequested()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    // =====================================================================
    // AMBIL FOTO (dengan opsi timer) + WATERMARK
    // =====================================================================

    private fun onCaptureRequested() {
        if (isCapturing) return
        if (timerSeconds > 0) {
            runCountdown(timerSeconds) { takePhoto() }
        } else {
            takePhoto()
        }
    }

    private fun runCountdown(seconds: Int, onFinish: () -> Unit) {
        isCapturing = true
        binding.tvCountdown.visibility = android.view.View.VISIBLE
        object : CountDownTimer(seconds * 1000L, 1000L) {
            override fun onTick(millisUntilFinished: Long) {
                binding.tvCountdown.text = ((millisUntilFinished / 1000) + 1).toString()
            }
            override fun onFinish() {
                binding.tvCountdown.visibility = android.view.View.GONE
                onFinish()
            }
        }.start()
    }

    private fun takePhoto() {
        val imageCapture = imageCapture ?: return
        isCapturing = true

        val nama = binding.etNama.text?.toString()?.ifBlank { "-" } ?: "-"
        val koptan = binding.etKoptan.text?.toString()?.ifBlank { "-" } ?: "-"
        val keterangan = binding.etKeterangan.text?.toString()?.ifBlank { "-" } ?: "-"
        val isFrontCamera = lensFacing == CameraSelector.LENS_FACING_FRONT

        imageCapture.takePicture(
            ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageCapturedCallback() {
                override fun onCaptureSuccess(image: ImageProxy) {
                    val bitmap = imageProxyToBitmap(image, isFrontCamera)
                    image.close()

                    val watermarked = addWatermark(
                        bitmap = bitmap,
                        nama = nama,
                        koptan = koptan,
                        keterangan = keterangan,
                        location = lastLocation
                    )

                    saveToGallery(watermarked, nama, koptan)
                    isCapturing = false
                }

                override fun onError(exception: ImageCaptureException) {
                    isCapturing = false
                    Toast.makeText(
                        this@MainActivity,
                        "Gagal mengambil foto: ${exception.message}",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        )
    }

    private fun imageProxyToBitmap(image: ImageProxy, isFrontCamera: Boolean): Bitmap {
        val buffer = image.planes[0].buffer
        val bytes = ByteArray(buffer.remaining())
        buffer.get(bytes)
        val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)

        // Putar sesuai orientasi sensor kamera (beda-beda tiap merek/perangkat)
        val matrix = Matrix()
        matrix.postRotate(image.imageInfo.rotationDegrees.toFloat())
        // Kamera depan biasanya perlu di-mirror agar tidak terbalik horizontal
        if (isFrontCamera) {
            matrix.postScale(-1f, 1f)
        }
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
    }

    private fun addWatermark(
        bitmap: Bitmap,
        nama: String,
        koptan: String,
        keterangan: String,
        location: Location?
    ): Bitmap {
        val result = bitmap.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(result)

        val baseTextSize = result.width * 0.032f
        val padding = result.width * 0.03f

        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = baseTextSize
            setShadowLayer(6f, 2f, 2f, Color.BLACK)
        }

        val bgPaint = Paint().apply {
            color = Color.argb(140, 0, 0, 0)
        }

        val sdf = SimpleDateFormat("dd MMM yyyy, HH:mm:ss", Locale("in", "ID"))
        val waktu = sdf.format(Date())

        val latText = location?.let { "%.6f".format(it.latitude) } ?: "-"
        val lonText = location?.let { "%.6f".format(it.longitude) } ?: "-"
        val altText = location?.let {
            if (it.hasAltitude()) "%.1f m".format(it.altitude) else "-"
        } ?: "-"

        val lines = listOf(
            "Nama       : $nama",
            "Koptan     : $koptan",
            "Keterangan : $keterangan",
            "Lat/Lon    : $latText, $lonText",
            "Ketinggian : $altText",
            "Waktu      : $waktu"
        )

        val lineHeight = baseTextSize * 1.35f
        val boxHeight = padding * 2 + lineHeight * lines.size
        val boxTop = result.height - boxHeight

        canvas.drawRect(0f, boxTop, result.width.toFloat(), result.height.toFloat(), bgPaint)

        var y = boxTop + padding + baseTextSize
        for (line in lines) {
            canvas.drawText(line, padding, y, textPaint)
            y += lineHeight
        }

        return result
    }

    // =====================================================================
    // SIMPAN KE GALERI (aman untuk Android 7 s/d versi terbaru)
    // =====================================================================

    private fun saveToGallery(bitmap: Bitmap, nama: String, koptan: String) {
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val safeNama = nama.replace(" ", "_")
        val safeKoptan = koptan.replace(" ", "_")
        val fileName = "${safeKoptan}_${safeNama}_$timeStamp.jpg"

        val contentValues = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/KameraGPS")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
        }

        val resolver = contentResolver
        val uri: Uri? = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)

        uri?.let {
            resolver.openOutputStream(it)?.use { out ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 95, out)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                contentValues.clear()
                contentValues.put(MediaStore.Images.Media.IS_PENDING, 0)
                resolver.update(it, contentValues, null, null)
            }
            Toast.makeText(this, "Foto tersimpan: $fileName", Toast.LENGTH_SHORT).show()
        } ?: Toast.makeText(this, "Gagal menyimpan foto", Toast.LENGTH_SHORT).show()
    }
}
